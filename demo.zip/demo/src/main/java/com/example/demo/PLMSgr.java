/*
 * Creation : 8 Apr 2020
 */
package com.example.demo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MBMQTSGR")
public class PLMSgr implements Serializable {

    public PLMSgr() {
        super();
    }

    public PLMSgr(String sgr, String cm) {
        this.sgr = sgr;
        this.cm = cm;
    }

    @Id
    @Column(name = "SGR", nullable = false)
    private String sgr;

    @Column(name = "CM")
    private String cm;

    public String getSgr() {
        return sgr;
    }

    public void setSgr(String sgr) {
        this.sgr = sgr;
    }

    public String getCm() {
        return cm;
    }

    public void setCm(String cm) {
        this.cm = cm;
    }

	@Override
	public String toString() {
		return "PLMSgr [sgr=" + sgr + ", cm=" + cm + "]";
	}
    
    
    

}
