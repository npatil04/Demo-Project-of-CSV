package com.example.demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;

public class DemoDaoImpl implements DemoDao {

	Collection PLMsgrs;

	@Autowired
	private EntityManager entityManager;

	public void readfile() throws IOException {
		String IN_SGRs = "C:/Seedstack_Workspace/demo/test/data/plmSGR.csv";

		BufferedReader bufReader = new BufferedReader(new FileReader(IN_SGRs));

		PLMsgrs = new ArrayList<>();

		String line = bufReader.readLine();

		while (line != null) {
			PLMsgrs.add(line);

			line = bufReader.readLine();
		}
		bufReader.close();

		// return null;

	}

	@Override
	public void cleanAllSgr() {

		// Collection plmSgrs = null;

		boolean cleanUpBeforeInsert = false;

		if (cleanUpBeforeInsert) {
			String insert = "INSERT INTO ABC(SGR,CM) VALUES (:sgr , :cm)";
			this.entityManager.createQuery(insert).executeUpdate();
			System.out.println("Inside If");
		}

		else {
			System.out.println("Inside else");
			String insert = "INSERT INTO ABC(SGR,CM) VALUES (:sgr , :cm)";
			this.entityManager.createQuery(insert).executeUpdate();
		}

		/*
		 * if (cleanUpBeforeInsert) { String deleteSGRQuery =
		 * "DELETE FROM ABC WHERE SGR IS NOT EQUALS TO NULL";
		 * this.entityManager.createQuery(deleteSGRQuery).executeUpdate(); }
		 * 
		 * for (Iterator iterator = PLMsgrs.iterator(); iterator.hasNext();) { PLMSgr
		 * bean = (PLMSgr) iterator.next(); entityManager.persist(bean); }
		 * 
		 * String insert = "INSERT INTO IONQTSGR(SGR,CM) VALUES (:sgr , :cm)";
		 * this.entityManager.createQuery(insert).executeUpdate();
		 */

	}

}
