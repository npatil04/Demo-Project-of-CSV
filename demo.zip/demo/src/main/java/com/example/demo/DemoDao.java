package com.example.demo;

public interface DemoDao {

	public void cleanAllSgr();
	
}
